<?php include_once("header.php");?>

<div class="card text-center">

  <div class="card-body">
      <h2>Faça parte da nossa história de amor, confirme sua presença.</h2>
      <h3>Confirme sua presença</h3>      
  </div>

  <form class="form-inline mx-auto">
  
  <input type="text" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Nome">

  <label class="sr-only" for="inlineFormInputGroupUsername2">Usuário</label>
  <div class="input-group mb-2 mr-sm-2">
    <div class="input-group-prepend">
      <div class="input-group-text">@</div>
    </div>
    <input type="text" class="form-control" id="inlineFormInputGroupUsername2" placeholder="E-mail">
  </div>

  <div class="form-check mb-2 mr-sm-2">
    <input class="form-check-input" type="checkbox" id="inlineFormCheck">
    <label class="form-check-label" for="inlineFormCheck">
      Lembrar de mim
    </label>
  </div>

  <button type="submit" class="btn btn-primary mb-2">Enviar</button>
</form>
  
</div>

<!--colocar o mapa do local do casamento-->


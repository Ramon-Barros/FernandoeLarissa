<?php include_once("header.php");?>

<div class="card-body card border-ligth mb-1 mx-auto d-block" style="width: 55rem;"id="fonte">
    <h5 class="card-title text-center">Olá queridos amigos e familiares!</h5>
        <p class="card-text">
            É com grande alegria que aniciamos nosso casamento!
              Para vocês que fizeram parte de nossas vidas, um convite para nos verem solterios pela última vez, casados pela única e felizes para sempre!
              Aqui vocês encontrarão um pouco sobre a nossa historia, fotos detalhe sobre o evento, sugestões na lista de presentes e muito mais.
            Esperamos ver o rostinho de cada um de vocês no nosso casamento para compartilhar e complementar a nossa felicidade!!!
                    Grande beijo! 
        </p>
                  
</div>


                
<?php include_once("footer.php");?>
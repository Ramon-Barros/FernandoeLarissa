<?php include_once("header.php");?>

<body style="background-image: url('img/alianças.jpg'); background-repeat: no-repeat;background-size: 100%;">

<div class="card" id="fonte">
  <div class="card-body">
  <p style="text-align: justify;">Queridos familiares e amigos,
        momentos especiais devem ser compartilhados com pessoas especiais.
        Gratidão pela presença!!!
        Então, para sua comodidade temos as seguintes opções da nossa lista de presentes:
        Presencial: IE São Luís – endereço: Av. Colares Moreira, Ed São Luís
        Multiempresarial, Jardim Renascença II, loja 10, São Luís.
        O seu presente pode ser parcelado em até 4x.</p>

        <p>
        Seu presente poderá ser pago via transferência bancária
        <b>Larissa L F Barros</b> Banco do Brasil <b>Agência:</b> 5784-3 Conta: 23.286-6
        Itaú – <b>Agência:</b> 7859 Conta: 00453-8
        </p>
  </div>
</div>
</body>
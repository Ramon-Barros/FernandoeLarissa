<?php include_once("header.php");?>

<img src="img/pic14.jpg" class="rounded float-left" alt="pic14.jpg">
<img src="img/pic15.jpg" class="rounded float-right" alt="pic14.jpg">
<img src="img/pic16.jpg" class="rounded mx-auto d-block" alt="pic14.jpg">

<?php include_once("footer.php");?>